#include <iostream>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <unistd.h>
#include <vector>
#include <cstring>
using namespace std;
// i生产者
int producer_num;
// j消费者
int consumer_num;
// k产品
int product_num;
// n缓冲区
int space_num;
//信号量
sem_t canProduce, canConsume, canSpace;

//产品类
class product
{
    public:
    int id;            //产品编号
    int producerID;    //生产者编号
    char *produceTime; //生产时间
    char *consumeTime; //生产时间
    int spaceID;       //缓冲区中存储编号
    int consumerID;    //消费者编号
    //打印产品信息
    void printProduct()
    {
        cout <<"                    产品编号：" << id <<endl<< "                    生产者编号：" << producerID <<endl<< "                    生产时间：" << produceTime <<endl<< "                    缓冲区存储编号：" << spaceID <<endl<< "                    消费者编号：" << consumerID <<endl<<"                    消费时间：" <<consumeTime<<endl<<"--------------------------------------------"<< endl;
    }
    //构造函数
    product(int id, int producerID, char *produceTime, int spaceID)
    {
        this->id = id;
        this->producerID = producerID;
        this->produceTime = produceTime;
        this->spaceID = spaceID;
        this->consumerID = -1;
        this->consumeTime = "-1";
    }
    

};

vector<product> space;      //缓冲区
int produce_num = 0;        //生产的产品数量
int consume_num = 0;        //消耗的产品数量

//打印缓冲区状态
void printSpace(int state)
{
    if (state == 1)
        cout << "【==========在生产前，";
    else if (state == 2)
        cout << "【==========在生产后，";
    else if (state == 3)
        cout << "【==========在消费前，";
    else if (state == 4)
        cout << "【==========在消费后，";
    cout << "各缓冲区产品的信息如下==========】" << endl;
    for (int i = 0; i < space_num; i++)
    {
        if (space.size() < i + 1)
        {
            cout << "                  第" << i+1 << "号缓冲区为空" << endl;
        }
        else
        {
            cout << "                  第" << i+1 << "号缓冲区内产品信息如下:"<<endl;
            space[i].printProduct();
        }
    }
    cout<<"【==================================================】"<<endl;
}

//生产者
void *producer(void *param)
{
    long rank = (long)param;//生产者线程序号
    while (true)
    {
        //如果生产和消费的产品数都超过product_num，则退出线程
        if (produce_num >= product_num && consume_num >= product_num)
            exit(0);
        //如果已生产的产品超过了product_num，则退出循环
        if (produce_num >= product_num)
            break;
        sem_wait(&canProduce); //等待能够生产
        cout << "生产者" << rank << "号获得1个生产名额" << endl;
        sem_wait(&canSpace); //等待能够操作缓冲区
        cout << "生产者" << rank << "号成功获得生产名额并进入缓冲区" << endl;
        //再次判断，防止有生产者在等待进入缓冲区的过程中所有生产者已经共生产了k件产品
        if (produce_num >= product_num)
        {
            cout << "生产者" << rank << "号离开缓冲区，因为此时已经生产了"<<product_num<<"件产品" << endl;
            sem_post(&canSpace);//释放缓冲区操作权
            break;//退出循环
        }
        //生产耗时
        int tmp = rand() % 5 + 1;
        cout << "【生产者" << rank << "号在生产中，将耗时" << tmp << "秒】" << endl;
        usleep(tmp);//生产耗时，生产线程进入睡眠
        printSpace(1);      //打印生产前的缓冲区状态
        produce_num++;//生产的产品数量加1
        time_t timep = time(0);
        char *produce_time = ctime(&timep);//获取当前时间
        produce_time[strlen(produce_time) - 1] = 0;//去掉换行符
        product p = product(produce_num, rank, produce_time,(space.size()+1));//创建产品，记录产品id,producerID,produceTime,spaceID记
        space.push_back(p); //将生产的产品放入缓冲区
        cout << "----------------------------------------------------------------------------------------------" << endl;
        cout << "生产者" << rank << "号生产完" << p.id << "号产品，离开缓冲区"<<p.spaceID<<"号" << endl;
        cout << "                  生产的"<< p.id << "号产品信息如下"<<endl;
        p.printProduct();
        cout << "目前总共生产了" << produce_num << "件产品" << endl;
        cout << "----------------------------------------------------------------------------------------------" << endl;
        printSpace(2);      //打印生产后的缓冲区状态
        sem_post(&canSpace);   //释放缓冲区操作权
        sem_post(&canConsume); //消费者可以消费的信号量加一
    }
    return NULL;
}
//消费者
void *consumer(void *param)
{
    long rank = (long)param;//消费者线程序号
    while (true)
    {
        //如果生产和消费的产品数都超过15，则退出
        if (produce_num >= product_num && consume_num >= product_num)
            exit(0);
        //如果已消费的产品超过了product_num，则退出循环
        if (consume_num >= product_num)
            break;
        sem_wait(&canConsume); //等待能够消费
        cout << "消费者" << rank << "号获得1个消费名额" << endl;
        sem_wait(&canSpace);//等待能够操作缓冲区
        cout << "消费者" << rank << "号获得消费名额并成功进入缓冲区" << endl;
        //再次判断，防止有消费者等待进入缓冲区的过程中所有消费者已经共消费了prodect_num件产品
        if (consume_num >= product_num)
        {
            cout << "消费者" << rank << "号离开缓冲区，因为已经消费了"<<product_num<<"件商品" << endl;
            sem_post(&canSpace);//释放缓冲区操作权
            break;
        }
        //消费耗时
        int tmp = rand() % 5 + 1;
        cout << "【消费者" << rank << "号在消费中，将耗时" << tmp << "秒】" << endl;
        usleep(tmp);//消费耗时，消费线程进入睡眠
        printSpace(3);    //打印消费前的缓冲区状态
        consume_num++;//消费的产品数量加1
        time_t timep = time(0);//获取当前时间
        char *consume_time = ctime(&timep);//获取当前时间
        consume_time[strlen(consume_time) - 1] = 0;//去掉换行符
        space[space.size() - 1].consumerID = rank;//记录消费者ID
        space[space.size() - 1].consumeTime = consume_time;//记录消费时间
        cout << "-------------------------------------------------------------------------------------------------" << endl;
        cout << "消费者" << rank << "号消费完" << space[space.size() - 1].id << "号产品，离开缓冲区"<<space[space.size() - 1].spaceID << "号"<< endl;
        cout << "                  消费的"<< space[space.size() - 1].id << "号产品信息如下"<<endl;
        space[space.size() - 1].printProduct();
        cout << "目前总共消费了" << consume_num << "件产品" << endl;
        cout << "--------------------------------------------------------------------------------------------------" << endl;
        space.pop_back(); //每次消费缓冲区vector的最后一件产品
        printSpace(4);    //打印消费后的缓冲区状态
        sem_post(&canSpace);   //释放缓冲区操作权
        sem_post(&canProduce); //生产者可以生产的信号量加一
    }
    return NULL;
}

int main()
{

    cout << "请输入生产者数量：";
    cin >> producer_num;
    cout << "请输入消费者数量：";
    cin >> consumer_num;
    cout << "请输入产品数量：";
    cin >> product_num;
    cout << "请输入缓冲区数量：";
    cin >> space_num;
    if(producer_num<=0){
        cout<<"没有生产者，无法生产产品"<<endl;
        return 0;
    }
    if(consumer_num<=0){
        cout<<"没有消费者，无法消费产品"<<endl;
        return 0;
    }
    if(product_num<=0){
        cout<<"所需要产品为0，无需进行生产或消费"<<endl;
        return 0;
    }
    if(space_num<=0){
        cout<<"缓存区为0,无法进行产品存储或消费"<<endl;
        return 0;
    }
    //初始化变量
    srand(time(NULL));//时间的随机种子
    pthread_t pid[producer_num];//生产者线程
    pthread_t cid[consumer_num];//消费者线程
    sem_init(&canProduce, 0, space_num);//信号量：生产者可以存放产品的缓存数
    sem_init(&canConsume, 0, 0);//信号量：消费者可以消费的产品数
    sem_init(&canSpace, 0, 1);//信号量：是否可以访问缓存区
     //创建多线程
     //创建生产者线程
    for (int i = 0; i < producer_num; i++)
    {
        pthread_create(&pid[i], NULL, producer, (void *)(i+1));
    }
    //创建消费者线程
    for (int i = 0; i < consumer_num; i++)
    {
        pthread_create(&cid[i], NULL, consumer, (void *)(i+1));
    }
    //回收线程
    for (int i = 0; i < producer_num; i++)
    {
        pthread_join(pid[i], NULL);
    }
    for (int i = 0; i < consumer_num; i++)
    {
        pthread_join(cid[i], NULL);
    }
    //回收信号量
    sem_destroy(&canProduce);
    sem_destroy(&canConsume);
    sem_destroy(&canSpace);

}