#include <linux/init.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/sched/task.h>
#include <linux/sched/signal.h>

/* init function  */
static int
hellokmodule_init(void)
{
	struct task_struct *p=&init_task;
    	printk(KERN_ALERT "2013747:simple module initialized\n");
    	printk("2013747:Jiffies value: %lu\n", jiffies);
    //准备打印进程信息
	printk("Hello new system call schello! 2013747 Zhang Yizhen\n");
	printk("%-20s %-6s %-11s %-6s %-10s\n","Name","Pid","Parent Pid","Stat","2013747");
	for_each_process(p){
		printk("%-20s %-6d %-11d %-6c %-10s\n",p->comm,p->pid,p->parent->pid,task_state_to_char(p),"2013747");
		}
	printk("2013747 Zhang Yizhen\n");

    return 0;
}

/* exit function - logs that the module is being removed */
static void
hellokmodule_exit(void)
{
    printk(KERN_ALERT "2013747:simple module is being unloaded\n");
    printk("2013747:Jiffies value: %lu\n", jiffies);
}

module_init(hellokmodule_init);
module_exit(hellokmodule_exit);

MODULE_LICENSE ("GPL");
MODULE_AUTHOR ("LKD");
MODULE_DESCRIPTION ("Simple Kernel Module");
MODULE_VERSION("1.01");
